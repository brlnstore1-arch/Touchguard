package com.touchguard.app.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.touchguard.app.model.FreezeEvent
import com.touchguard.app.model.MetricSample

class DatabaseHelper private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "touchguard.db"
        private const val DB_VERSION = 1

        // Freeze events table
        const val TABLE_FREEZES = "freeze_events"
        const val COL_ID = "_id"
        const val COL_TIMESTAMP = "timestamp"
        const val COL_RAM_USED = "ram_used_mb"
        const val COL_RAM_TOTAL = "ram_total_mb"
        const val COL_BATT_TEMP = "battery_temp"
        const val COL_BATT_LEVEL = "battery_level"
        const val COL_CPU = "cpu_load"
        const val COL_TOP_APP = "top_app"
        const val COL_NOTES = "notes"

        // Metric samples table
        const val TABLE_SAMPLES = "metric_samples"

        @Volatile
        private var instance: DatabaseHelper? = null

        fun getInstance(context: Context): DatabaseHelper =
            instance ?: synchronized(this) {
                instance ?: DatabaseHelper(context).also { instance = it }
            }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE $TABLE_FREEZES (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TIMESTAMP INTEGER NOT NULL,
                $COL_RAM_USED INTEGER,
                $COL_RAM_TOTAL INTEGER,
                $COL_BATT_TEMP REAL,
                $COL_BATT_LEVEL INTEGER,
                $COL_CPU INTEGER,
                $COL_TOP_APP TEXT,
                $COL_NOTES TEXT
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE $TABLE_SAMPLES (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TIMESTAMP INTEGER NOT NULL,
                $COL_RAM_USED INTEGER,
                $COL_RAM_TOTAL INTEGER,
                $COL_BATT_TEMP REAL,
                $COL_BATT_LEVEL INTEGER,
                $COL_CPU INTEGER
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_FREEZES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_SAMPLES")
        onCreate(db)
    }

    // ── Freeze Events ──────────────────────────────────────────────────────────

    fun insertFreeze(event: FreezeEvent): Long {
        val cv = ContentValues().apply {
            put(COL_TIMESTAMP, event.timestamp)
            put(COL_RAM_USED, event.ramUsedMb)
            put(COL_RAM_TOTAL, event.ramTotalMb)
            put(COL_BATT_TEMP, event.batteryTemp)
            put(COL_BATT_LEVEL, event.batteryLevel)
            put(COL_CPU, event.cpuLoadPercent)
            put(COL_TOP_APP, event.topApp)
            put(COL_NOTES, event.notes)
        }
        return writableDatabase.insert(TABLE_FREEZES, null, cv)
    }

    fun getAllFreezes(): List<FreezeEvent> {
        val list = mutableListOf<FreezeEvent>()
        val cursor = readableDatabase.query(
            TABLE_FREEZES, null, null, null, null, null,
            "$COL_TIMESTAMP DESC"
        )
        cursor.use {
            while (it.moveToNext()) {
                list.add(
                    FreezeEvent(
                        id = it.getLong(it.getColumnIndexOrThrow(COL_ID)),
                        timestamp = it.getLong(it.getColumnIndexOrThrow(COL_TIMESTAMP)),
                        ramUsedMb = it.getInt(it.getColumnIndexOrThrow(COL_RAM_USED)),
                        ramTotalMb = it.getInt(it.getColumnIndexOrThrow(COL_RAM_TOTAL)),
                        batteryTemp = it.getFloat(it.getColumnIndexOrThrow(COL_BATT_TEMP)),
                        batteryLevel = it.getInt(it.getColumnIndexOrThrow(COL_BATT_LEVEL)),
                        cpuLoadPercent = it.getInt(it.getColumnIndexOrThrow(COL_CPU)),
                        topApp = it.getString(it.getColumnIndexOrThrow(COL_TOP_APP)) ?: "",
                        notes = it.getString(it.getColumnIndexOrThrow(COL_NOTES)) ?: ""
                    )
                )
            }
        }
        return list
    }

    fun deleteFreeze(id: Long) {
        writableDatabase.delete(TABLE_FREEZES, "$COL_ID=?", arrayOf(id.toString()))
    }

    fun getFreezeCount(): Int {
        val cursor = readableDatabase.rawQuery("SELECT COUNT(*) FROM $TABLE_FREEZES", null)
        return cursor.use { if (it.moveToFirst()) it.getInt(0) else 0 }
    }

    // ── Metric Samples ─────────────────────────────────────────────────────────

    fun insertSample(sample: MetricSample) {
        val cv = ContentValues().apply {
            put(COL_TIMESTAMP, sample.timestamp)
            put(COL_RAM_USED, sample.ramUsedMb)
            put(COL_RAM_TOTAL, sample.ramTotalMb)
            put(COL_BATT_TEMP, sample.batteryTemp)
            put(COL_BATT_LEVEL, sample.batteryLevel)
            put(COL_CPU, sample.cpuLoadPercent)
        }
        writableDatabase.insert(TABLE_SAMPLES, null, cv)
        // Keep only last 500 samples
        writableDatabase.execSQL(
            "DELETE FROM $TABLE_SAMPLES WHERE $COL_ID NOT IN " +
                    "(SELECT $COL_ID FROM $TABLE_SAMPLES ORDER BY $COL_TIMESTAMP DESC LIMIT 500)"
        )
    }

    fun getRecentSamples(limit: Int = 60): List<MetricSample> {
        val list = mutableListOf<MetricSample>()
        val cursor = readableDatabase.query(
            TABLE_SAMPLES, null, null, null, null, null,
            "$COL_TIMESTAMP DESC", limit.toString()
        )
        cursor.use {
            while (it.moveToNext()) {
                list.add(
                    MetricSample(
                        id = it.getLong(it.getColumnIndexOrThrow(COL_ID)),
                        timestamp = it.getLong(it.getColumnIndexOrThrow(COL_TIMESTAMP)),
                        ramUsedMb = it.getInt(it.getColumnIndexOrThrow(COL_RAM_USED)),
                        ramTotalMb = it.getInt(it.getColumnIndexOrThrow(COL_RAM_TOTAL)),
                        batteryTemp = it.getFloat(it.getColumnIndexOrThrow(COL_BATT_TEMP)),
                        batteryLevel = it.getInt(it.getColumnIndexOrThrow(COL_BATT_LEVEL)),
                        cpuLoadPercent = it.getInt(it.getColumnIndexOrThrow(COL_CPU))
                    )
                )
            }
        }
        return list.reversed()
    }
}
