package com.touchguard.app.util

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.touchguard.app.model.MetricSample
import java.io.File

object SystemMetrics {

    fun collectSample(context: Context): MetricSample {
        val ram = getRamInfo(context)
        val battInfo = getBatteryInfo(context)
        return MetricSample(
            timestamp = System.currentTimeMillis(),
            ramUsedMb = ram.first,
            ramTotalMb = ram.second,
            batteryTemp = battInfo.first,
            batteryLevel = battInfo.second,
            cpuLoadPercent = getCpuLoad()
        )
    }

    /** Returns Pair(usedMb, totalMb) */
    fun getRamInfo(context: Context): Pair<Int, Int> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val totalMb = (info.totalMem / 1024 / 1024).toInt()
        val availMb = (info.availMem / 1024 / 1024).toInt()
        val usedMb = totalMb - availMb
        return Pair(usedMb, totalMb)
    }

    /** Returns Pair(tempCelsius, levelPercent) */
    fun getBatteryInfo(context: Context): Pair<Float, Int> {
        val intent = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )
        val rawTemp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val temp = rawTemp / 10f
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (scale > 0) (level * 100 / scale) else 0
        return Pair(temp, percent)
    }

    /** Reads /proc/stat to estimate overall CPU usage 0-100 */
    fun getCpuLoad(): Int {
        return try {
            val stat1 = readCpuStat()
            Thread.sleep(150)
            val stat2 = readCpuStat()

            val idle1 = stat1[3]
            val idle2 = stat2[3]
            val total1 = stat1.sum()
            val total2 = stat2.sum()

            val totalDiff = total2 - total1
            val idleDiff = idle2 - idle1

            if (totalDiff > 0) ((totalDiff - idleDiff) * 100 / totalDiff).toInt().coerceIn(0, 100)
            else 0
        } catch (e: Exception) {
            0
        }
    }

    private fun readCpuStat(): List<Long> {
        return try {
            val line = File("/proc/stat").bufferedReader().readLine() ?: return emptyList()
            line.trim().split("\\s+".toRegex())
                .drop(1) // remove "cpu" prefix
                .take(7)
                .map { it.toLongOrNull() ?: 0L }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun formatRam(usedMb: Int, totalMb: Int): String = "${usedMb}MB / ${totalMb}MB"

    fun formatTemp(celsius: Float): String = String.format("%.1f°C", celsius)
}
