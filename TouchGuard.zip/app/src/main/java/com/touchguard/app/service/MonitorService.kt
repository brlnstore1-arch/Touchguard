package com.touchguard.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.touchguard.app.R
import com.touchguard.app.db.DatabaseHelper
import com.touchguard.app.ui.MainActivity
import com.touchguard.app.util.SystemMetrics
import kotlinx.coroutines.*

class MonitorService : Service() {

    companion object {
        const val CHANNEL_ID = "touchguard_monitor"
        const val NOTIF_ID = 1001
        const val ACTION_STOP = "com.touchguard.ACTION_STOP"
        const val SAMPLE_INTERVAL_MS = 30_000L
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var db: DatabaseHelper

    override fun onCreate() {
        super.onCreate()
        db = DatabaseHelper.getInstance(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification())
        startSampling()
        return START_STICKY
    }

    private fun startSampling() {
        scope.launch {
            while (isActive) {
                try {
                    val sample = SystemMetrics.collectSample(this@MonitorService)
                    db.insertSample(sample)
                } catch (e: Exception) { }
                delay(SAMPLE_INTERVAL_MS)
            }
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MonitorService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TouchGuard ativo")
            .setContentText("Monitorando o touch do celular...")
            .setSmallIcon(R.drawable.ic_shield)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_stop, "Parar", stopIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Monitor TouchGuard", NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Monitoramento em segundo plano"
            setShowBadge(false)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
