package com.touchguard.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.os.SystemClock
import android.telephony.TelephonyManager
import android.util.Log
import java.io.File

/**
 * TouchRefreshManager — tenta recuperar o touch por múltiplos métodos.
 *
 * O *#2663# é o código oficial Samsung para atualizar o firmware do TSP.
 * Como não funciona diretamente no A06 nessa situação, tentamos alternativas
 * em ordem crescente de agressividade.
 */
object TouchRefreshManager {

    private const val TAG = "TouchRefreshManager"

    data class RefreshResult(
        val method: String,
        val success: Boolean,
        val message: String
    )

    /**
     * Executa todos os métodos de recuperação em sequência.
     * Retorna a lista de resultados para análise.
     */
    fun runAllMethods(context: Context): List<RefreshResult> {
        val results = mutableListOf<RefreshResult>()

        results.add(method1_DialerCode(context))
        Thread.sleep(500)
        results.add(method2_UssdDirect(context))
        Thread.sleep(500)
        results.add(method3_ScreenCycle(context))
        Thread.sleep(1000)
        results.add(method4_SysFsEnable(context))
        Thread.sleep(500)
        results.add(method5_InputSensitivity(context))

        return results
    }

    /**
     * Método 1: Abre o discador com *#2663# pré-preenchido.
     * O usuário precisa apertar "ligar" — mas a tela já fica pronta.
     */
    fun method1_DialerCode(context: Context): RefreshResult {
        return try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:*%232663%23")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            RefreshResult(
                "Discador *#2663#",
                true,
                "Discador aberto com o código. Pressione 'Ligar' para ativar a atualização do TSP."
            )
        } catch (e: Exception) {
            Log.e(TAG, "method1 falhou: ${e.message}")
            RefreshResult("Discador *#2663#", false, "Erro: ${e.message}")
        }
    }

    /**
     * Método 2: Envia USSD *#2663# diretamente via TelephonyManager.
     * Funciona em alguns modelos Samsung sem precisar abrir o discador.
     */
    fun method2_UssdDirect(context: Context): RefreshResult {
        return try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            // Usa reflexão pois sendUssdRequest requer permissão CALL_PHONE em alguns níveis
            val method = tm.javaClass.getMethod(
                "sendUssdRequest",
                String::class.java,
                android.telephony.TelephonyManager.UssdResponseCallback::class.java,
                android.os.Handler::class.java
            )
            method.invoke(tm, "*#2663#", object :
                TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(
                    telephonyManager: TelephonyManager,
                    request: String,
                    response: CharSequence
                ) {
                    Log.d(TAG, "USSD resposta: $response")
                }
                override fun onReceiveUssdResponseFailed(
                    telephonyManager: TelephonyManager,
                    request: String,
                    failureCode: Int
                ) {
                    Log.e(TAG, "USSD falhou: $failureCode")
                }
            }, null)
            RefreshResult(
                "USSD Direto *#2663#",
                true,
                "Comando USSD enviado ao modem. Aguarde resposta do sistema."
            )
        } catch (e: Exception) {
            Log.w(TAG, "method2 não disponível: ${e.message}")
            RefreshResult(
                "USSD Direto *#2663#",
                false,
                "Não disponível neste dispositivo (${e.javaClass.simpleName})"
            )
        }
    }

    /**
     * Método 3: Ciclo de tela apagada/acesa.
     * Força o driver do touch a reiniciar, pois a maioria dos TSP
     * tem lógica de reset no evento de wakeup da tela.
     */
    fun method3_ScreenCycle(context: Context): RefreshResult {
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val wakeLock = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "TouchGuard:reset"
            )
            // Apaga a tela brevemente e acende novamente
            wakeLock.acquire(3000L)
            Thread.sleep(300)
            // O driver do TSP detecta o wakeup e faz reset interno
            wakeLock.release()
            Thread.sleep(800)
            wakeLock.acquire(5000L)
            wakeLock.release()

            RefreshResult(
                "Ciclo Tela (Wake Reset)",
                true,
                "Tela ciclada — driver do TSP forçado a reinicializar no wakeup."
            )
        } catch (e: Exception) {
            Log.e(TAG, "method3 falhou: ${e.message}")
            RefreshResult("Ciclo Tela", false, "Erro: ${e.message}")
        }
    }

    /**
     * Método 4: Desativa e reativa o dispositivo de toque via sysfs.
     * Funciona sem root em alguns kernels do Samsung que expõem o nó
     * /sys/class/input/inputX/device/enabled como gravável pelo app.
     */
    fun method4_SysFsEnable(context: Context): RefreshResult {
        val devices = TouchDeviceInfo.findTouchDevices()
        if (devices.isEmpty()) {
            return RefreshResult(
                "SysFS Enable/Disable",
                false,
                "Dispositivo de toque não encontrado no kernel"
            )
        }

        var successCount = 0
        val messages = mutableListOf<String>()

        for (device in devices) {
            val enabledFile = File("${device.sysPath}/device/enabled")
            if (!enabledFile.exists()) {
                messages.add("${device.name}: nó 'enabled' não exposto")
                continue
            }
            if (!enabledFile.canWrite()) {
                messages.add("${device.name}: sem permissão de escrita (sem root)")
                continue
            }
            try {
                enabledFile.writeText("0")
                Thread.sleep(300)
                enabledFile.writeText("1")
                successCount++
                messages.add("${device.name}: ✅ reiniciado via sysfs")
            } catch (e: Exception) {
                messages.add("${device.name}: erro — ${e.message}")
            }
        }

        return RefreshResult(
            "SysFS Enable/Disable",
            successCount > 0,
            messages.joinToString("\n")
        )
    }

    /**
     * Método 5: Reescreve a sensibilidade do touch.
     * Alguns drivers Samsung expõem /sys/.../sensitivity como gravável,
     * e reescrever o valor força o controlador a reprocessar a configuração.
     */
    fun method5_InputSensitivity(context: Context): RefreshResult {
        val devices = TouchDeviceInfo.findTouchDevices()
        if (devices.isEmpty()) {
            return RefreshResult("Recalibração de Sensibilidade", false,
                "Dispositivo não encontrado")
        }

        var touched = false
        val msgs = mutableListOf<String>()

        for (device in devices) {
            val base = "${device.sysPath}/device"
            // Caminhos comuns em drivers Samsung/Zinitix/Goodix
            val targets = listOf(
                "$base/sensitivity",
                "$base/glove_mode",
                "$base/covertype",
                "$base/tsp_sensitivity"
            )
            for (path in targets) {
                val f = File(path)
                if (f.exists() && f.canRead()) {
                    val current = try { f.readText().trim() } catch (e: Exception) { continue }
                    if (f.canWrite()) {
                        try {
                            f.writeText(current) // reescreve o mesmo valor → força recarga
                            msgs.add("$path = $current (reescrito)")
                            touched = true
                        } catch (e: Exception) {
                            msgs.add("$path: leitura OK, escrita negada")
                        }
                    } else {
                        msgs.add("$path = $current (somente leitura)")
                    }
                }
            }
        }

        return RefreshResult(
            "Recalibração de Sensibilidade",
            touched,
            if (msgs.isEmpty()) "Nenhum nó de sensibilidade encontrado"
            else msgs.joinToString("\n")
        )
    }

    /** Formata o relatório de resultados para exibição */
    fun formatResults(results: List<RefreshResult>): String {
        return buildString {
            results.forEachIndexed { i, r ->
                appendLine("${i + 1}. ${r.method}")
                appendLine("   ${if (r.success) "✅" else "❌"} ${r.message}")
                appendLine()
            }
        }.trimEnd()
    }
}
