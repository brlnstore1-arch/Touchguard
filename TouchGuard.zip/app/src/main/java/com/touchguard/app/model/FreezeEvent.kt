package com.touchguard.app.model

data class FreezeEvent(
    val id: Long = 0,
    val timestamp: Long,           // epoch ms
    val ramUsedMb: Int,
    val ramTotalMb: Int,
    val batteryTemp: Float,        // graus Celsius
    val batteryLevel: Int,         // porcentagem
    val cpuLoadPercent: Int,       // estimativa
    val topApp: String,            // app em primeiro plano (best effort)
    val notes: String = ""
) {
    val ramUsedPercent: Int get() = if (ramTotalMb > 0) (ramUsedMb * 100 / ramTotalMb) else 0
}
