package com.touchguard.app.util

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.File
import java.io.RandomAccessFile

/**
 * GlobalErrorDetector — varre fontes do sistema em busca de pistas
 * sobre o congelamento do toque, sem necessitar de root.
 */
object GlobalErrorDetector {

    data class DiagnosticReport(
        val touchDeviceReport: String,
        val kernelHints: List<String>,
        val memoryPressure: MemoryPressure,
        val thermalStatus: ThermalStatus,
        val topProcesses: List<ProcessInfo>,
        val storageStatus: StorageStatus,
        val displayInfo: String,
        val possibleCauses: List<String>,
        val recommendation: String
    )

    data class MemoryPressure(
        val totalMb: Int,
        val usedMb: Int,
        val availMb: Int,
        val lowMemory: Boolean,
        val threshold: Int
    )

    data class ThermalStatus(
        val batteryTempC: Float,
        val cpuTempC: Float?,
        val skinTempC: Float?,
        val isOverheating: Boolean
    )

    data class ProcessInfo(
        val name: String,
        val pid: Int,
        val memKb: Long
    )

    data class StorageStatus(
        val totalGb: Float,
        val freeGb: Float,
        val freePercent: Int,
        val isLow: Boolean
    )

    fun runFullDiagnostic(context: Context): DiagnosticReport {
        val touchReport = TouchDeviceInfo.buildReport()
        val kernelHints = readKernelHints()
        val mem = getMemoryPressure(context)
        val thermal = getThermalStatus(context)
        val procs = getTopProcesses(context)
        val storage = getStorageStatus()
        val display = getDisplayInfo(context)
        val causes = analyzeCauses(mem, thermal, storage, kernelHints)
        val rec = buildRecommendation(causes, mem, thermal)

        return DiagnosticReport(
            touchDeviceReport = touchReport,
            kernelHints = kernelHints,
            memoryPressure = mem,
            thermalStatus = thermal,
            topProcesses = procs,
            storageStatus = storage,
            displayInfo = display,
            possibleCauses = causes,
            recommendation = rec
        )
    }

    /** Lê /proc/last_kmsg e dmesg em busca de erros relacionados ao touch */
    private fun readKernelHints(): List<String> {
        val hints = mutableListOf<String>()
        val touchKeywords = listOf(
            "tsp", "touchscreen", "i2c", "goodix", "zinitix", "ztw",
            "sec_ts", "fts", "synaptics", "input", "firmware", "fw_update",
            "irq", "timeout", "error", "failed", "reset", "suspend", "resume"
        )

        val sources = listOf(
            "/proc/last_kmsg",
            "/proc/kmsg",
            "/sys/fs/pstore/console-ramoops-0",
            "/sys/fs/pstore/dmesg-ramoops-0"
        )

        for (source in sources) {
            try {
                val f = File(source)
                if (!f.exists() || !f.canRead()) continue

                // Lê apenas os últimos 50KB para não travar
                val size = f.length()
                val readFrom = maxOf(0L, size - 50_000L)
                val raf = RandomAccessFile(f, "r")
                raf.seek(readFrom)
                val buf = ByteArray((size - readFrom).toInt())
                raf.read(buf)
                raf.close()

                val lines = String(buf).lines()
                for (line in lines) {
                    val lower = line.lowercase()
                    if (touchKeywords.any { lower.contains(it) }) {
                        val clean = line.trim().take(120)
                        if (clean.isNotBlank() && !hints.contains(clean)) {
                            hints.add(clean)
                        }
                    }
                }
                if (hints.isNotEmpty()) break // achou no primeiro arquivo disponível
            } catch (e: Exception) {
                // sem permissão é normal
            }
        }

        return hints.takeLast(20) // últimos 20 eventos relevantes
    }

    fun getMemoryPressure(context: Context): MemoryPressure {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val total = (info.totalMem / 1024 / 1024).toInt()
        val avail = (info.availMem / 1024 / 1024).toInt()
        val threshold = (info.threshold / 1024 / 1024).toInt()
        return MemoryPressure(
            totalMb = total,
            usedMb = total - avail,
            availMb = avail,
            lowMemory = info.lowMemory,
            threshold = threshold
        )
    }

    fun getThermalStatus(context: Context): ThermalStatus {
        val (battTemp, _) = SystemMetrics.getBatteryInfo(context)
        val cpuTemp = readThermalZone("cpu") ?: readSysThermal(0)
        val skinTemp = readThermalZone("skin") ?: readSysThermal(4)

        return ThermalStatus(
            batteryTempC = battTemp,
            cpuTempC = cpuTemp,
            skinTempC = skinTemp,
            isOverheating = battTemp >= 43f || (cpuTemp ?: 0f) >= 70f
        )
    }

    private fun readThermalZone(keyword: String): Float? {
        return try {
            val thermalDir = File("/sys/class/thermal")
            if (!thermalDir.exists()) return null
            thermalDir.listFiles()?.forEach { zone ->
                val typeFile = File(zone, "type")
                if (typeFile.exists() && typeFile.readText().contains(keyword, ignoreCase = true)) {
                    val temp = File(zone, "temp").readText().trim().toLongOrNull()
                    if (temp != null) return temp / 1000f
                }
            }
            null
        } catch (e: Exception) { null }
    }

    private fun readSysThermal(zone: Int): Float? {
        return try {
            val f = File("/sys/class/thermal/thermal_zone$zone/temp")
            if (f.exists()) f.readText().trim().toLong() / 1000f else null
        } catch (e: Exception) { null }
    }

    fun getTopProcesses(context: Context): List<ProcessInfo> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return try {
            val processes = am.runningAppProcesses ?: return emptyList()
            processes.mapNotNull { proc ->
                try {
                    val memInfo = am.getProcessMemoryInfo(intArrayOf(proc.pid))
                    val kb = memInfo.firstOrNull()?.totalPss?.toLong() ?: 0L
                    ProcessInfo(
                        name = proc.processName.substringAfterLast(":").substringAfterLast("."),
                        pid = proc.pid,
                        memKb = kb
                    )
                } catch (e: Exception) { null }
            }.sortedByDescending { it.memKb }.take(8)
        } catch (e: Exception) { emptyList() }
    }

    fun getStorageStatus(): StorageStatus {
        return try {
            val stat = android.os.StatFs(android.os.Environment.getDataDirectory().path)
            val total = stat.totalBytes / 1024 / 1024 / 1024f
            val free = stat.availableBytes / 1024 / 1024 / 1024f
            val pct = if (total > 0) (free / total * 100).toInt() else 0
            StorageStatus(total, free, pct, pct < 10)
        } catch (e: Exception) {
            StorageStatus(0f, 0f, 0, false)
        }
    }

    private fun getDisplayInfo(context: Context): String {
        return try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
            val metrics = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getMetrics(metrics)
            val refreshRate = @Suppress("DEPRECATION") wm.defaultDisplay.refreshRate
            "Resolução: ${metrics.widthPixels}x${metrics.heightPixels} | " +
                    "DPI: ${metrics.densityDpi} | " +
                    "Taxa de atualização: ${String.format("%.0f", refreshRate)}Hz"
        } catch (e: Exception) { "Informação de tela indisponível" }
    }

    private fun analyzeCauses(
        mem: MemoryPressure,
        thermal: ThermalStatus,
        storage: StorageStatus,
        kernelHints: List<String>
    ): List<String> {
        val causes = mutableListOf<String>()

        val ramPct = if (mem.totalMb > 0) mem.usedMb * 100 / mem.totalMb else 0

        if (mem.lowMemory) causes.add("🔴 CRÍTICO: Sistema em estado de pouca memória (Low Memory Killer ativo) — pode matar o driver do touch")
        else if (ramPct >= 88) causes.add("🟠 RAM muito alta ($ramPct%) — sistema sob pressão severa")
        else if (ramPct >= 75) causes.add("🟡 RAM elevada ($ramPct%) — pode contribuir para instabilidade")

        if (thermal.batteryTempC >= 45f) causes.add("🔴 CRÍTICO: Temperatura da bateria muito alta (${thermal.batteryTempC}°C) — throttling pode afetar o touch")
        else if (thermal.batteryTempC >= 42f) causes.add("🟠 Temperatura elevada (${thermal.batteryTempC}°C) — dispositivo aquecido")
        thermal.cpuTempC?.let {
            if (it >= 70f) causes.add("🔴 CPU superaquecida ($it°C)")
            else if (it >= 60f) causes.add("🟡 CPU aquecida ($it°C)")
        }

        if (storage.isLow) causes.add("🟠 Armazenamento muito cheio (${storage.freePercent}% livre) — pode afetar paginação e swap")

        val touchErrors = kernelHints.filter { line ->
            listOf("error", "fail", "timeout", "i2c nack", "reset").any { line.lowercase().contains(it) }
        }
        if (touchErrors.isNotEmpty()) causes.add("🔴 Erros de hardware detectados nos logs do kernel (${touchErrors.size} ocorrências)")

        val fwLines = kernelHints.filter { it.lowercase().contains("firmware") || it.lowercase().contains("fw") }
        if (fwLines.isNotEmpty()) causes.add("ℹ️ Referências a firmware encontradas nos logs — pode ser bug de versão de FW")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            causes.add("ℹ️ Android 14+ — verifique atualizações de sistema pendentes")
        }

        if (causes.isEmpty()) causes.add("✅ Nenhuma causa óbvia detectada — pode ser bug de driver esporádico")

        return causes
    }

    private fun buildRecommendation(
        causes: List<String>,
        mem: MemoryPressure,
        thermal: ThermalStatus
    ): String {
        return buildString {
            appendLine("📋 RECOMENDAÇÕES:")
            if (causes.any { it.contains("RAM") || it.contains("memória") }) {
                appendLine("• Feche apps em segundo plano (${mem.usedMb}MB em uso)")
                appendLine("• Considere desativar apps desnecessários")
            }
            if (causes.any { it.contains("temperatura") || it.contains("Temperatura") || it.contains("quecida") }) {
                appendLine("• Deixe o celular descansar em local fresco")
                appendLine("• Remova a capinha para melhorar dissipação de calor")
            }
            if (causes.any { it.contains("armazenamento") || it.contains("Armazenamento") }) {
                appendLine("• Libere espaço de armazenamento")
                appendLine("• Esvazie a lixeira de fotos/vídeos")
            }
            if (causes.any { it.contains("firmware") || it.contains("driver") }) {
                appendLine("• Use a função 'Atualizar Touch' no menu do TouchGuard")
                appendLine("• Verifique atualizações do sistema em Configurações > Software")
            }
            appendLine("• Se o problema persistir: Configurações > Gerenciamento geral > Redefinir > Redefinir configurações")
        }.trimEnd()
    }

    /** Formata o relatório completo como texto legível */
    fun formatReport(report: DiagnosticReport): String {
        return buildString {
            appendLine("═══ DIAGNÓSTICO COMPLETO ═══")
            appendLine()

            appendLine("── HARDWARE DE TOQUE ──")
            appendLine(report.touchDeviceReport)
            appendLine()

            appendLine("── MEMÓRIA ──")
            val ramPct = if (report.memoryPressure.totalMb > 0)
                report.memoryPressure.usedMb * 100 / report.memoryPressure.totalMb else 0
            appendLine("Usada: ${report.memoryPressure.usedMb}MB / ${report.memoryPressure.totalMb}MB ($ramPct%)")
            appendLine("Disponível: ${report.memoryPressure.availMb}MB")
            appendLine("Low Memory: ${if (report.memoryPressure.lowMemory) "⚠️ SIM" else "✅ Não"}")
            appendLine()

            appendLine("── TEMPERATURA ──")
            appendLine("Bateria: ${String.format("%.1f", report.thermalStatus.batteryTempC)}°C")
            report.thermalStatus.cpuTempC?.let { appendLine("CPU: ${String.format("%.1f", it)}°C") }
            report.thermalStatus.skinTempC?.let { appendLine("Carcaça: ${String.format("%.1f", it)}°C") }
            appendLine()

            appendLine("── ARMAZENAMENTO ──")
            appendLine("Livre: ${String.format("%.1f", report.storageStatus.freeGb)}GB / ${String.format("%.1f", report.storageStatus.totalGb)}GB (${report.storageStatus.freePercent}% livre)")
            appendLine()

            appendLine("── TELA ──")
            appendLine(report.displayInfo)
            appendLine()

            if (report.topProcesses.isNotEmpty()) {
                appendLine("── PROCESSOS (RAM) ──")
                report.topProcesses.forEach {
                    appendLine("  ${it.name.padEnd(20)} ${it.memKb / 1024}MB")
                }
                appendLine()
            }

            if (report.kernelHints.isNotEmpty()) {
                appendLine("── LOGS DO KERNEL (touch) ──")
                report.kernelHints.takeLast(5).forEach { appendLine("  $it") }
                appendLine()
            }

            appendLine("── POSSÍVEIS CAUSAS ──")
            report.possibleCauses.forEach { appendLine(it) }
            appendLine()

            appendLine(report.recommendation)
        }
    }
}
