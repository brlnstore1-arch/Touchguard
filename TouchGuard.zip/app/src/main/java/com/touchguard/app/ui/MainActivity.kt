package com.touchguard.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.touchguard.app.R
import com.touchguard.app.databinding.ActivityMainBinding
import com.touchguard.app.db.DatabaseHelper
import com.touchguard.app.model.FreezeEvent
import com.touchguard.app.service.FloatingButtonService
import com.touchguard.app.service.MonitorService
import com.touchguard.app.util.SystemMetrics
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var db: DatabaseHelper
    private val handler = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale("pt", "BR"))

    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshMetrics()
            handler.postDelayed(this, 5_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        db = DatabaseHelper.getInstance(this)
        startMonitorService()
        setupButtons()
        refreshMetrics()
        refreshFreezeCount()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refreshRunnable)
        refreshFreezeCount()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refreshRunnable)
    }

    private fun startMonitorService() {
        ContextCompat.startForegroundService(this, Intent(this, MonitorService::class.java))
    }

    private fun setupButtons() {
        binding.btnRegisterFreeze.setOnClickListener {
            binding.btnRegisterFreeze.isEnabled = false
            binding.btnRegisterFreeze.text = "⏳ Registrando…"
            handler.postDelayed({
                binding.btnRegisterFreeze.isEnabled = true
                binding.btnRegisterFreeze.text = "⚠️ TOQUE TRAVOU!"
            }, 1500)
            registerFreeze()
        }

        binding.btnViewHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        binding.btnDiagnostic.setOnClickListener {
            startActivity(Intent(this, DiagnosticActivity::class.java))
        }

        binding.btnFloating.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                ContextCompat.startForegroundService(
                    this, Intent(this, FloatingButtonService::class.java)
                )
                AlertDialog.Builder(this)
                    .setTitle("Botão flutuante ativado")
                    .setMessage(
                        "O botão ⚡ aparece em cima de tudo.\n\n" +
                        "• Toque rápido → registra o freeze\n" +
                        "• Toque longo (2s) → tenta recuperar o touch\n\n" +
                        "Arraste para mover o botão."
                    )
                    .setPositiveButton("OK", null)
                    .show()
            } else {
                AlertDialog.Builder(this)
                    .setTitle("Permissão necessária")
                    .setMessage("Para o botão flutuante funcionar, o TouchGuard precisa da permissão de 'Aparecer sobre outros apps'.")
                    .setPositiveButton("Permitir") { _, _ ->
                        startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName"))
                        )
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }
    }

    private fun registerFreeze() {
        Thread {
            val ram = SystemMetrics.getRamInfo(this)
            val batt = SystemMetrics.getBatteryInfo(this)
            val cpu = SystemMetrics.getCpuLoad()
            val event = FreezeEvent(
                timestamp = System.currentTimeMillis(),
                ramUsedMb = ram.first,
                ramTotalMb = ram.second,
                batteryTemp = batt.first,
                batteryLevel = batt.second,
                cpuLoadPercent = cpu,
                topApp = "tela principal"
            )
            db.insertFreeze(event)
            runOnUiThread {
                refreshFreezeCount()
                showRegisteredFeedback(event)
            }
        }.start()
    }

    private fun showRegisteredFeedback(event: FreezeEvent) {
        AlertDialog.Builder(this)
            .setTitle("✅ Freeze Capturado")
            .setMessage(buildString {
                appendLine("🕐 ${fmt.format(Date(event.timestamp))}")
                appendLine("🧠 RAM: ${event.ramUsedMb}MB/${event.ramTotalMb}MB (${event.ramUsedPercent}%)")
                appendLine("🌡️ Temperatura: ${String.format("%.1f", event.batteryTemp)}°C")
                appendLine("🔋 Bateria: ${event.batteryLevel}%")
                appendLine("⚡ CPU: ${event.cpuLoadPercent}%")
                appendLine()
                appendLine("Use o Diagnóstico para analisar possíveis causas.")
            })
            .setPositiveButton("OK", null)
            .setNeutralButton("Ver Diagnóstico") { _, _ ->
                startActivity(Intent(this, DiagnosticActivity::class.java))
            }
            .show()
    }

    private fun refreshMetrics() {
        Thread {
            val ram = SystemMetrics.getRamInfo(this)
            val batt = SystemMetrics.getBatteryInfo(this)
            runOnUiThread {
                val pct = if (ram.second > 0) ram.first * 100 / ram.second else 0
                binding.tvRamValue.text = "${ram.first}MB / ${ram.second}MB"
                binding.pbRam.progress = pct
                binding.tvRamPercent.text = "$pct%"
                setProgressColor(binding.pbRam, pct)
                binding.tvTempValue.text = String.format("%.1f°C", batt.first)
                binding.tvTempStatus.text = getTempStatus(batt.first)
                binding.tvTempStatus.setTextColor(getTempColor(batt.first))
                binding.tvBattValue.text = "${batt.second}%"
                binding.tvLastUpdate.text = "Atualizado: ${
                    SimpleDateFormat("HH:mm:ss", Locale("pt","BR")).format(Date())
                }"
            }
        }.start()
    }

    private fun refreshFreezeCount() {
        Thread {
            val count = db.getFreezeCount()
            runOnUiThread {
                binding.tvFreezeCount.text = count.toString()
                binding.tvFreezeLabel.text = if (count == 1) "freeze registrado" else "freezes registrados"
            }
        }.start()
    }

    private fun getTempStatus(temp: Float) = when {
        temp < 35f -> "Normal ✅"
        temp < 42f -> "Morno ⚠️"
        temp < 48f -> "Quente 🔴"
        else -> "MUITO QUENTE 🔴"
    }

    private fun getTempColor(temp: Float) = when {
        temp < 35f -> ContextCompat.getColor(this, R.color.status_ok)
        temp < 42f -> ContextCompat.getColor(this, R.color.status_warn)
        else -> ContextCompat.getColor(this, R.color.status_danger)
    }

    private fun setProgressColor(pb: android.widget.ProgressBar, percent: Int) {
        val color = when {
            percent < 70 -> ContextCompat.getColor(this, R.color.status_ok)
            percent < 85 -> ContextCompat.getColor(this, R.color.status_warn)
            else -> ContextCompat.getColor(this, R.color.status_danger)
        }
        pb.progressTintList = android.content.res.ColorStateList.valueOf(color)
    }
}
