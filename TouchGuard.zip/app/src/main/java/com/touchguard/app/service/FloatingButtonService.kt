package com.touchguard.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.touchguard.app.R
import com.touchguard.app.db.DatabaseHelper
import com.touchguard.app.model.FreezeEvent
import com.touchguard.app.ui.MainActivity
import com.touchguard.app.util.SystemMetrics
import com.touchguard.app.util.TouchRefreshManager
import kotlinx.coroutines.*

/**
 * FloatingButtonService — exibe um botão flutuante sempre visível.
 * Mesmo com o touch travado, o botão de overlay pode responder
 * pois usa TYPE_APPLICATION_OVERLAY com prioridade máxima de input.
 *
 * O botão tem dois modos:
 *  - Toque simples → registra freeze
 *  - Toque longo (2s) → tenta refresh do touch automaticamente
 */
class FloatingButtonService : Service() {

    companion object {
        const val CHANNEL_ID = "touchguard_float"
        const val NOTIF_ID = 1002
        const val ACTION_STOP = "com.touchguard.FLOAT_STOP"
    }

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // Posição do botão (arrastável)
    private var lastX = 0f
    private var lastY = 0f
    private var initX = 0
    private var initY = 0
    private var touchStartTime = 0L
    private var isDragging = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        showFloatingButton()
    }

    private fun showFloatingButton() {
        val btn = TextView(this).apply {
            text = "⚡"
            textSize = 22f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(220, 61, 142, 255))
            gravity = android.view.Gravity.CENTER
            setPadding(20, 20, 20, 20)
            elevation = 10f
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 300
        }

        btn.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.rawX
                    lastY = event.rawY
                    initX = params.x
                    initY = params.y
                    touchStartTime = System.currentTimeMillis()
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - lastX
                    val dy = event.rawY - lastY
                    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) isDragging = true
                    if (isDragging) {
                        params.x = initX + dx.toInt()
                        params.y = initY + dy.toInt()
                        windowManager.updateViewLayout(v, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val elapsed = System.currentTimeMillis() - touchStartTime
                    if (!isDragging) {
                        if (elapsed >= 1500) {
                            // Toque longo → tenta refresh
                            onLongPress(btn)
                        } else {
                            // Toque curto → registra freeze
                            onShortPress(btn)
                        }
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(btn, params)
        floatingView = btn
    }

    private fun onShortPress(btn: TextView) {
        btn.text = "⏳"
        btn.setBackgroundColor(Color.argb(220, 231, 76, 60))
        scope.launch {
            val ram = SystemMetrics.getRamInfo(this@FloatingButtonService)
            val batt = SystemMetrics.getBatteryInfo(this@FloatingButtonService)
            val cpu = SystemMetrics.getCpuLoad()

            val event = FreezeEvent(
                timestamp = System.currentTimeMillis(),
                ramUsedMb = ram.first,
                ramTotalMb = ram.second,
                batteryTemp = batt.first,
                batteryLevel = batt.second,
                cpuLoadPercent = cpu,
                topApp = "via botão flutuante",
                notes = "Registrado via overlay"
            )
            DatabaseHelper.getInstance(this@FloatingButtonService).insertFreeze(event)

            withContext(Dispatchers.Main) {
                btn.text = "✅"
                btn.setBackgroundColor(Color.argb(220, 46, 204, 113))
                delay(2000)
                btn.text = "⚡"
                btn.setBackgroundColor(Color.argb(220, 61, 142, 255))
            }
        }
    }

    private fun onLongPress(btn: TextView) {
        btn.text = "🔄"
        btn.setBackgroundColor(Color.argb(220, 243, 156, 18))
        scope.launch {
            // Executa apenas o método mais seguro (ciclo de tela)
            TouchRefreshManager.method3_ScreenCycle(this@FloatingButtonService)
            withContext(Dispatchers.Main) {
                btn.text = "✅"
                btn.setBackgroundColor(Color.argb(220, 46, 204, 113))
                delay(2000)
                btn.text = "⚡"
                btn.setBackgroundColor(Color.argb(220, 61, 142, 255))
            }
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingButtonService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Botão flutuante ativo")
            .setContentText("⚡ toque = registrar  |  toque longo = refresh")
            .setSmallIcon(R.drawable.ic_shield)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_stop, "Parar", stopIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Botão Flutuante", NotificationManager.IMPORTANCE_LOW
        ).apply { setShowBadge(false) }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        floatingView?.let { windowManager.removeView(it) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
