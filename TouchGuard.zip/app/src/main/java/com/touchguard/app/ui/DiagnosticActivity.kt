package com.touchguard.app.ui

import android.os.Bundle
import android.view.View
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.touchguard.app.R
import com.touchguard.app.databinding.ActivityDiagnosticBinding
import com.touchguard.app.util.GlobalErrorDetector
import com.touchguard.app.util.TouchDeviceInfo
import com.touchguard.app.util.TouchRefreshManager

class DiagnosticActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDiagnosticBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDiagnosticBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.btnRunDiagnostic.setOnClickListener { runDiagnostic() }
        binding.btnRefreshTouch.setOnClickListener { runTouchRefresh() }
        binding.btnRefreshMethod1.setOnClickListener { runSingleMethod(1) }
        binding.btnRefreshMethod3.setOnClickListener { runSingleMethod(3) }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    private fun runDiagnostic() {
        binding.btnRunDiagnostic.isEnabled = false
        binding.btnRunDiagnostic.text = "Analisando…"
        binding.progressBar.visibility = View.VISIBLE
        binding.tvOutput.text = ""

        Thread {
            val report = GlobalErrorDetector.runFullDiagnostic(this)
            val text = GlobalErrorDetector.formatReport(report)
            runOnUiThread {
                binding.tvOutput.text = text
                binding.progressBar.visibility = View.GONE
                binding.btnRunDiagnostic.isEnabled = true
                binding.btnRunDiagnostic.text = "🔍 Executar Diagnóstico"
                binding.scrollOutput.post {
                    binding.scrollOutput.smoothScrollTo(0, 0)
                }
            }
        }.start()
    }

    private fun runTouchRefresh() {
        binding.btnRefreshTouch.isEnabled = false
        binding.btnRefreshTouch.text = "Executando…"
        binding.progressBar.visibility = View.VISIBLE

        Thread {
            val results = TouchRefreshManager.runAllMethods(this)
            val text = "═══ ATUALIZAÇÃO DE TOUCH ═══\n\n" +
                    TouchRefreshManager.formatResults(results)
            runOnUiThread {
                binding.tvOutput.text = text
                binding.progressBar.visibility = View.GONE
                binding.btnRefreshTouch.isEnabled = true
                binding.btnRefreshTouch.text = "🔄 Atualizar Touch (todos métodos)"
            }
        }.start()
    }

    private fun runSingleMethod(method: Int) {
        binding.progressBar.visibility = View.VISIBLE
        Thread {
            val result = when (method) {
                1 -> TouchRefreshManager.method1_DialerCode(this)
                3 -> TouchRefreshManager.method3_ScreenCycle(this)
                else -> return@Thread
            }
            val text = "Método: ${result.method}\n" +
                    "Resultado: ${if (result.success) "✅ Sucesso" else "❌ Falhou"}\n\n" +
                    result.message
            runOnUiThread {
                binding.tvOutput.text = text
                binding.progressBar.visibility = View.GONE
            }
        }.start()
    }
}
