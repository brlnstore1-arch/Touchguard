package com.touchguard.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.touchguard.app.R
import com.touchguard.app.databinding.ActivityHistoryBinding
import com.touchguard.app.db.DatabaseHelper
import com.touchguard.app.model.FreezeEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private lateinit var db: DatabaseHelper
    private lateinit var adapter: FreezeAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        db = DatabaseHelper.getInstance(this)
        adapter = FreezeAdapter(mutableListOf()) { event -> confirmDelete(event) }
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        loadData()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    private fun loadData() {
        Thread {
            val events = db.getAllFreezes()
            runOnUiThread {
                adapter.setData(events)
                binding.tvEmpty.visibility = if (events.isEmpty()) View.VISIBLE else View.GONE
                binding.tvTotal.text = "${events.size} evento(s) registrado(s)"
            }
        }.start()
    }

    private fun confirmDelete(event: FreezeEvent) {
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale("pt","BR"))
        AlertDialog.Builder(this)
            .setTitle("Excluir registro")
            .setMessage("Remover freeze de ${fmt.format(Date(event.timestamp))}?")
            .setPositiveButton("Excluir") { _, _ ->
                Thread {
                    db.deleteFreeze(event.id)
                    runOnUiThread { loadData() }
                }.start()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── Adapter ───────────────────────────────────────────────────────────────

    inner class FreezeAdapter(
        private val data: MutableList<FreezeEvent>,
        private val onDelete: (FreezeEvent) -> Unit
    ) : RecyclerView.Adapter<FreezeAdapter.VH>() {

        fun setData(list: List<FreezeEvent>) {
            data.clear()
            data.addAll(list)
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_freeze, parent, false)
            return VH(v)
        }

        override fun getItemCount() = data.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.bind(data[position])
        }

        inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val tvDate: TextView = itemView.findViewById(R.id.tv_date)
            private val tvRam: TextView = itemView.findViewById(R.id.tv_ram)
            private val tvTemp: TextView = itemView.findViewById(R.id.tv_temp)
            private val tvBatt: TextView = itemView.findViewById(R.id.tv_batt)
            private val tvCpu: TextView = itemView.findViewById(R.id.tv_cpu)
            private val tvDelete: TextView = itemView.findViewById(R.id.tv_delete)

            fun bind(event: FreezeEvent) {
                val fmt = SimpleDateFormat("dd/MM/yyyy  HH:mm:ss", Locale("pt","BR"))
                tvDate.text = fmt.format(Date(event.timestamp))
                tvRam.text = "🧠 RAM: ${event.ramUsedMb}MB/${event.ramTotalMb}MB (${event.ramUsedPercent}%)"
                tvTemp.text = "🌡️ Temp: ${String.format("%.1f", event.batteryTemp)}°C"
                tvBatt.text = "🔋 Bateria: ${event.batteryLevel}%"
                tvCpu.text = "⚡ CPU: ${event.cpuLoadPercent}%"
                tvDelete.setOnClickListener { onDelete(event) }
            }
        }
    }
}
