package com.touchguard.app.util

import java.io.File

/**
 * Lê informações do hardware de toque diretamente do kernel Linux
 * via /sys/class/input/ e /proc/bus/input/devices
 * Não requer root — são arquivos públicos de leitura.
 */
object TouchDeviceInfo {

    data class TouchDevice(
        val inputNode: String,       // ex: input4
        val name: String,            // ex: sec_touchscreen
        val vendor: String,
        val product: String,
        val sysPath: String,
        val firmwareVersion: String,
        val driverVersion: String,
        val isActive: Boolean,
        val extraProps: Map<String, String>
    )

    /** Lê /proc/bus/input/devices e retorna todos os dispositivos de toque */
    fun findTouchDevices(): List<TouchDevice> {
        val devices = mutableListOf<TouchDevice>()
        try {
            val content = File("/proc/bus/input/devices").readText()
            val blocks = content.split("\n\n").filter { it.isNotBlank() }

            for (block in blocks) {
                val lines = block.trim().lines()
                val props = mutableMapOf<String, String>()
                for (line in lines) {
                    val idx = line.indexOf(':')
                    if (idx > 0) {
                        val key = line.substring(0, idx).trim()
                        val value = line.substring(idx + 1).trim()
                        props[key] = value
                    }
                }

                val name = props["N"]?.trim('"') ?: ""
                val handlers = props["H"] ?: ""

                // Filtra apenas dispositivos de toque
                val isTouchDevice = name.contains("touch", ignoreCase = true) ||
                        name.contains("ts", ignoreCase = true) ||
                        name.contains("sec_e-", ignoreCase = true) ||
                        name.contains("synaptics", ignoreCase = true) ||
                        name.contains("goodix", ignoreCase = true) ||
                        name.contains("fts", ignoreCase = true) ||
                        name.contains("ztw", ignoreCase = true) ||
                        name.contains("ist", ignoreCase = true)

                if (!isTouchDevice) continue

                val inputNode = Regex("input(\\d+)").find(handlers)
                    ?.groupValues?.get(0) ?: "input?"
                val sysPath = "/sys/class/input/$inputNode"

                val fw = readSysFile("$sysPath/device/firmware_version")
                    ?: readSysFile("$sysPath/device/ic_fw_version")
                    ?: readSysFile("$sysPath/device/fw_version")
                    ?: "desconhecido"

                val driver = readSysFile("$sysPath/device/driver/description")
                    ?: readSysFile("$sysPath/../driver/description")
                    ?: name

                val idParts = props["I"]?.split(" ") ?: emptyList()
                val vendor = idParts.find { it.startsWith("Vendor=") }
                    ?.substringAfter("=") ?: "?"
                val product = idParts.find { it.startsWith("Product=") }
                    ?.substringAfter("=") ?: "?"

                val isActive = File("$sysPath/device/enabled").let {
                    if (it.exists()) it.readText().trim() == "1" else true
                }

                // Propriedades extras do dispositivo
                val extra = mutableMapOf<String, String>()
                listOf("sensitivity", "mode", "ic_type", "module_vendor",
                    "hw_version", "config_version", "tsp_state").forEach { prop ->
                    readSysFile("$sysPath/device/$prop")
                        ?.let { extra[prop] = it }
                }

                devices.add(
                    TouchDevice(
                        inputNode = inputNode,
                        name = name,
                        vendor = vendor,
                        product = product,
                        sysPath = sysPath,
                        firmwareVersion = fw,
                        driverVersion = driver,
                        isActive = isActive,
                        extraProps = extra
                    )
                )
            }
        } catch (e: Exception) {
            // /proc pode não existir em alguns ambientes
        }
        return devices
    }

    /** Lê o estado atual do touch (enabled/disabled/power mode) */
    fun getTouchState(): String {
        val devices = findTouchDevices()
        if (devices.isEmpty()) return "Dispositivo de toque não identificado"
        val d = devices.first()
        val enabled = readSysFile("${d.sysPath}/device/enabled") ?: "?"
        val power = readSysFile("${d.sysPath}/device/power_state")
            ?: readSysFile("${d.sysPath}/device/power/runtime_status")
            ?: "?"
        return "enabled=$enabled | power=$power"
    }

    /** Verifica se há erros reportados pelo driver */
    fun getDriverErrors(): String {
        val devices = findTouchDevices()
        if (devices.isEmpty()) return "—"
        val d = devices.first()
        return readSysFile("${d.sysPath}/device/error_log")
            ?: readSysFile("${d.sysPath}/device/diag")
            ?: "Sem erros reportados"
    }

    /** Lê o número de eventos de toque processados (se disponível) */
    fun getTouchEventCount(): Long {
        return try {
            val stat = File("/proc/bus/input/devices").readText()
            // Conta eventos lidos do device de toque via /dev/input/eventX
            0L // placeholder — leitura real requer permissão de root
        } catch (e: Exception) { 0L }
    }

    private fun readSysFile(path: String): String? {
        return try {
            val f = File(path)
            if (f.exists() && f.canRead()) f.readText().trim().takeIf { it.isNotBlank() }
            else null
        } catch (e: Exception) { null }
    }

    /** Formata o relatório completo para exibição */
    fun buildReport(): String {
        val devices = findTouchDevices()
        if (devices.isEmpty()) {
            return "⚠️ Nenhum dispositivo de toque encontrado em /proc/bus/input/devices\n" +
                    "(Normal em alguns dispositivos com kernel restritivo)"
        }

        return buildString {
            devices.forEach { d ->
                appendLine("📟 ${d.name}")
                appendLine("   Firmware: ${d.firmwareVersion}")
                appendLine("   Driver:   ${d.driverVersion}")
                appendLine("   Node:     ${d.inputNode}  (${d.sysPath})")
                appendLine("   Vendor/Product: ${d.vendor}/${d.product}")
                appendLine("   Ativo: ${if (d.isActive) "✅ Sim" else "❌ Não"}")
                if (d.extraProps.isNotEmpty()) {
                    appendLine("   Extras:")
                    d.extraProps.forEach { (k, v) -> appendLine("     $k = $v") }
                }
            }
        }.trimEnd()
    }
}
