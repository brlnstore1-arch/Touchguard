package com.touchguard.app.model

data class MetricSample(
    val id: Long = 0,
    val timestamp: Long,
    val ramUsedMb: Int,
    val ramTotalMb: Int,
    val batteryTemp: Float,
    val batteryLevel: Int,
    val cpuLoadPercent: Int
)
