#!/usr/bin/env python3
"""
TouchGuard Bot — manda o ZIP, recebe o APK.

Dependências:
    pip install requests

Configuração (edite as variáveis abaixo):
    BOT_TOKEN   → token do BotFather
    ALLOWED_ID  → seu chat_id no Telegram (mande /start pro bot, ele te mostra)
    GITHUB_TOKEN → Personal Access Token (repo + workflow)
    GITHUB_REPO  → usuario/repositorio  ex: brlnstore1-arch/TouchGuard
    LOCAL_REPO   → caminho local do repositório clonado
"""

import os, time, zipfile, shutil, subprocess, requests, json, sys

# ─── CONFIGURAÇÃO ──────────────────────────────────────────────────────────────
BOT_TOKEN    = "SEU_TOKEN_AQUI"
ALLOWED_ID   = 0          # seu chat_id (inteiro)
GITHUB_TOKEN = "SEU_GITHUB_TOKEN_AQUI"
GITHUB_REPO  = "seu-usuario/TouchGuard"
LOCAL_REPO   = "/caminho/para/TouchGuard"   # pasta clonada localmente
# ───────────────────────────────────────────────────────────────────────────────

API = f"https://api.telegram.org/bot{BOT_TOKEN}"
GH  = "https://api.github.com"
HEADERS_GH = {
    "Authorization": f"Bearer {GITHUB_TOKEN}",
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28"
}

def send(chat_id, text):
    requests.post(f"{API}/sendMessage", json={"chat_id": chat_id, "text": text})

def send_file(chat_id, path, caption=""):
    with open(path, "rb") as f:
        requests.post(f"{API}/sendDocument",
                      data={"chat_id": chat_id, "caption": caption},
                      files={"document": f})

def get_updates(offset=0):
    r = requests.get(f"{API}/getUpdates",
                     params={"offset": offset, "timeout": 30}, timeout=35)
    return r.json().get("result", [])

def download_file(file_id, dest):
    r = requests.get(f"{API}/getFile", params={"file_id": file_id}).json()
    path = r["result"]["file_path"]
    url = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{path}"
    data = requests.get(url).content
    with open(dest, "wb") as f:
        f.write(data)

def extract_zip_to_repo(zip_path):
    """Extrai o ZIP substituindo os arquivos do repositório local."""
    tmp = "/tmp/tg_extract"
    if os.path.exists(tmp):
        shutil.rmtree(tmp)
    os.makedirs(tmp)

    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(tmp)

    # Se o ZIP tiver uma pasta raiz (ex: TouchGuard/), entra nela
    items = os.listdir(tmp)
    if len(items) == 1 and os.path.isdir(os.path.join(tmp, items[0])):
        src = os.path.join(tmp, items[0])
    else:
        src = tmp

    # Copia tudo para o repo local (preserva .git)
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(LOCAL_REPO, item)
        if item == ".git":
            continue
        if os.path.isdir(s):
            if os.path.exists(d):
                shutil.rmtree(d)
            shutil.copytree(s, d)
        else:
            shutil.copy2(s, d)

def git_push():
    """Commita e envia para o GitHub."""
    cmds = [
        ["git", "-C", LOCAL_REPO, "add", "-A"],
        ["git", "-C", LOCAL_REPO, "commit", "-m",
         f"build: atualização via Telegram [{time.strftime('%d/%m %H:%M')}]"],
        ["git", "-C", LOCAL_REPO, "push"]
    ]
    for cmd in cmds:
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0 and "nothing to commit" not in result.stdout:
            raise RuntimeError(result.stderr or result.stdout)

def get_latest_run_id():
    """Retorna o ID do workflow run mais recente."""
    url = f"{GH}/repos/{GITHUB_REPO}/actions/runs"
    r = requests.get(url, headers=HEADERS_GH, params={"per_page": 1}).json()
    runs = r.get("workflow_runs", [])
    return runs[0]["id"] if runs else None

def wait_for_run(run_id, chat_id):
    """Aguarda o workflow terminar, enviando status a cada 30s."""
    url = f"{GH}/repos/{GITHUB_REPO}/actions/runs/{run_id}"
    start = time.time()
    last_status = ""

    while True:
        r = requests.get(url, headers=HEADERS_GH).json()
        status     = r.get("status", "")
        conclusion = r.get("conclusion", "")
        elapsed    = int(time.time() - start)

        if status != last_status:
            send(chat_id, f"⏳ Compilando… [{elapsed}s]\nStatus: {status}")
            last_status = status

        if status == "completed":
            return conclusion

        if elapsed > 600:  # 10 min timeout
            return "timeout"

        time.sleep(30)

def download_apk(run_id, dest):
    """Baixa o APK do artifact do run."""
    url = f"{GH}/repos/{GITHUB_REPO}/actions/runs/{run_id}/artifacts"
    r = requests.get(url, headers=HEADERS_GH).json()
    artifacts = r.get("artifacts", [])
    if not artifacts:
        return False

    artifact_id = artifacts[0]["id"]
    dl_url = f"{GH}/repos/{GITHUB_REPO}/actions/artifacts/{artifact_id}/zip"
    resp = requests.get(dl_url, headers=HEADERS_GH, stream=True)

    zip_path = dest + ".zip"
    with open(zip_path, "wb") as f:
        for chunk in resp.iter_content(8192):
            f.write(chunk)

    with zipfile.ZipFile(zip_path, "r") as z:
        apk_files = [n for n in z.namelist() if n.endswith(".apk")]
        if not apk_files:
            return False
        z.extract(apk_files[0], os.path.dirname(dest))
        extracted = os.path.join(os.path.dirname(dest), apk_files[0])
        os.rename(extracted, dest)

    return True

# ─── LOOP PRINCIPAL ────────────────────────────────────────────────────────────

def main():
    print("🤖 TouchGuard Bot iniciado!")
    offset = 0

    while True:
        try:
            updates = get_updates(offset)
        except Exception as e:
            print(f"Erro getUpdates: {e}")
            time.sleep(5)
            continue

        for upd in updates:
            offset = upd["update_id"] + 1
            msg = upd.get("message", {})
            chat_id = msg.get("chat", {}).get("id")
            text = msg.get("text", "")
            doc  = msg.get("document")

            if not chat_id:
                continue

            # Verificação de segurança
            if ALLOWED_ID != 0 and chat_id != ALLOWED_ID:
                send(chat_id, "❌ Acesso não autorizado.")
                continue

            # /start — mostra chat_id
            if text.strip() == "/start":
                send(chat_id,
                     f"👋 TouchGuard Bot\n\n"
                     f"Seu chat_id: {chat_id}\n\n"
                     f"Mande o ZIP do projeto para compilar.")
                continue

            # /status — verifica último run
            if text.strip() == "/status":
                run_id = get_latest_run_id()
                if run_id:
                    send(chat_id, f"Último run ID: {run_id}\n"
                                  f"https://github.com/{GITHUB_REPO}/actions/runs/{run_id}")
                else:
                    send(chat_id, "Nenhum run encontrado.")
                continue

            # Recebeu um arquivo ZIP
            if doc and doc.get("file_name", "").endswith(".zip"):
                send(chat_id, "📥 ZIP recebido! Iniciando processo…")
                zip_path = "/tmp/touchguard_upload.zip"

                try:
                    # 1. Baixa o ZIP
                    download_file(doc["file_id"], zip_path)
                    send(chat_id, "✅ ZIP baixado. Extraindo e enviando para o GitHub…")

                    # 2. Extrai para o repo e faz push
                    extract_zip_to_repo(zip_path)
                    git_push()
                    send(chat_id, "📤 Push feito! Aguardando o GitHub Actions compilar…")

                    # 3. Aguarda o run iniciar (pode demorar alguns segundos)
                    time.sleep(8)
                    run_id = get_latest_run_id()
                    if not run_id:
                        send(chat_id, "❌ Não encontrei o workflow. Verifique o GitHub.")
                        continue

                    # 4. Aguarda conclusão
                    conclusion = wait_for_run(run_id, chat_id)

                    if conclusion == "success":
                        send(chat_id, "✅ Compilação concluída! Baixando APK…")
                        apk_path = "/tmp/TouchGuard-debug.apk"
                        if download_apk(run_id, apk_path):
                            send_file(chat_id, apk_path, "🎉 TouchGuard.apk — instale no A06!")
                        else:
                            send(chat_id,
                                 f"⚠️ Compilou mas não consegui baixar o APK.\n"
                                 f"Baixe manualmente:\n"
                                 f"https://github.com/{GITHUB_REPO}/actions/runs/{run_id}")
                    elif conclusion == "timeout":
                        send(chat_id, "⏰ Timeout — compilação demorou mais de 10 min.")
                    else:
                        send(chat_id,
                             f"❌ Falhou ({conclusion})\n"
                             f"Ver log: https://github.com/{GITHUB_REPO}/actions/runs/{run_id}")

                except Exception as e:
                    send(chat_id, f"❌ Erro: {e}")
                    print(f"Erro: {e}")

            elif doc:
                send(chat_id, "⚠️ Manda um arquivo .zip do projeto.")

if __name__ == "__main__":
    main()
