# TouchGuard — Setup do Bot

## O que o bot faz
Você manda o ZIP → ele sobe pro GitHub → compila → te manda o APK de volta no Telegram.

---

## 1. Criar o repositório no GitHub

1. Crie um repo chamado `TouchGuard` (pode ser privado)
2. Extraia o ZIP e envie os arquivos para a **raiz** do repo
3. Verifique se o `.github/workflows/build.yml` está lá

---

## 2. Criar o token do GitHub

1. GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Clique em **Generate new token (classic)**
3. Marque: `repo` (tudo) + `workflow`
4. Copie o token gerado

---

## 3. Criar o bot no Telegram

1. Abra o [@BotFather](https://t.me/BotFather) no Telegram
2. Mande `/newbot` e siga as instruções
3. Copie o **token** gerado (formato `123456:ABC-DEF...`)

---

## 4. Configurar o bot.py

Abra o arquivo `bot.py` e edite as 4 linhas no topo:

```python
BOT_TOKEN    = "SEU_TOKEN_AQUI"       # token do BotFather
ALLOWED_ID   = 0                       # veja abaixo como descobrir
GITHUB_TOKEN = "SEU_GITHUB_TOKEN_AQUI"
GITHUB_REPO  = "seu-usuario/TouchGuard"
LOCAL_REPO   = "/caminho/para/TouchGuard"  # pasta do repo clonado no PC
```

**Para descobrir seu ALLOWED_ID:**
Inicie o bot (`python3 bot.py`), mande `/start` para ele no Telegram,
ele vai responder com o seu chat_id. Coloque esse número no ALLOWED_ID.

---

## 5. Clonar o repositório no PC onde o bot vai rodar

```bash
git clone https://github.com/seu-usuario/TouchGuard.git /caminho/para/TouchGuard
```

Configure o git com suas credenciais:
```bash
git config --global user.email "seu@email.com"
git config --global user.name "Seu Nome"
git config --global credential.helper store
# Faça um push manual uma vez para salvar a senha/token
```

---

## 6. Instalar dependências e rodar

```bash
pip install requests
python3 bot.py
```

Para rodar em segundo plano (Linux):
```bash
nohup python3 bot.py &
```

---

## 7. Usar

1. Abra o seu bot no Telegram
2. Mande `/start` para testar
3. **Mande o ZIP do projeto** — o bot vai:
   - Extrair o ZIP no repositório local
   - Fazer push para o GitHub
   - Aguardar a compilação (~3-5 min)
   - Te mandar o APK pronto

### Comandos disponíveis
| Comando | Função |
|---------|--------|
| `/start` | Mostra seu chat_id e instruções |
| `/status` | Mostra o último run do GitHub Actions |
| Enviar `.zip` | Inicia compilação completa |

---

## Observações

- O bot precisa ficar **rodando no PC** enquanto você usa
- O repositório precisa estar **clonado localmente** no mesmo PC que roda o bot
- O GitHub Actions compila na nuvem — só precisa de internet
